Compile main.tex with pdfLaTeX, BibTeX and pdfLaTeX twice. IEEE template assets are at the archive root; figures are in images/.
